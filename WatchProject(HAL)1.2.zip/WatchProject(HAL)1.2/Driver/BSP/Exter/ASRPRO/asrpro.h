#ifndef __ASRPRO_H
#define __ASRPRO_H

#include "sys/sys.h"
#include "menu/menu.h"

#define MENUNAME_ARRSIZE		10

extern char* menuNameArr[MAX_LEVEL][MENUNAME_ARRSIZE];

void voiceControlGetInfo(void);
void backStdTime(void);
void toggleArrowPoint(char* menuName);
char *getName(char* name, uint8_t *level);

#endif



#ifndef __JX90164_H
#define __JX90164_H

#include "sys/sys.h"

/* jx90164ģ���豸��ַ */
#define JX90164_DEVICE_ADDRESS				0x7F

/* JX90164ģ��I2Cͨ�Ŷ�д����ָ�� */
#define JX90164_I2C_WRITE					(JX90164_DEVICE_ADDRESS << 1)
#define JX90164_I2C_READ					(JX90164_DEVICE_ADDRESS << 1) + 1

/* jx90164ģ���ڼĴ�����ַ */
#define JX90164_SOFT_RESET					0x00
#define JX90164_DATA_READY1					0x02
#define JX90164_DATA_READY2					0x03
#define JX90164_ERROR_CODE					0x04
#define JX90164_DATA1_MSB					0x10
#define JX90164_DATA1_CSB					0x11
#define JX90164_DATA1_LSB					0x12
#define JX90164_TEMP_MSB					0x16
#define JX90164_TEMP_CSB					0x17
#define JX90164_TEMP_LSB					0x18
#define JX90164_DATA1_CAL_MSB				0x19
#define JX90164_DATA1_CAL_CSB				0x1A
#define JX90164_DATA1_CAL_LSB				0x1B
#define JX90164_DATA2_CAL_MSB				0x1C
#define JX90164_DATA2_CAL_CSB				0x1D
#define JX90164_DATA2_CAL_LSB				0x1E
#define JX90164_DATA1_RAW_MSB				0x22
#define JX90164_DATA1_RAW_CSB				0x23
#define JX90164_DATA1_RAW_LSB				0x24
#define JX90164_DATA2_RAW_MSB				0x25
#define JX90164_DATA2_RAW_CSB				0x26
#define JX90164_DATA2_RAW_LSB				0x27
#define JX90164_TEMP_RAW_MSB				0x28
#define JX90164_TEMP_RAW_CSB				0x29
#define JX90164_TEMP_RAW_LSB				0x2A
#define JX90164_CMD							0x30
#define JX90164_SLEEP_TIME					0x31
#define JX90164_BLOW_START					0x40



void jx90164_Init(void);
void jx90164_Write_Register(uint8_t registerAddress, uint8_t data);
int8_t jx90164_Read_Register(uint8_t registerAddress);
void jx90164_Cmd(void);
void jx90164_CmdFSM(void);



#endif



#ifndef __TEMPERATURE_H
#define __TEMPERATURE_H

#include "sys/sys.h"

/* ��������500 */
#define SAMPLE_SIZE				500

extern int8_t tempSampleArr[SAMPLE_SIZE];
extern float tempResult;
extern uint8_t tempResultDecimal;

void computeTemp(void);
void showTemp(void);
void enterOrQuitTemp(void);



#endif



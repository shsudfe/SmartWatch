#ifndef __SECONDWATCH_H
#define __SECONDWATCH_H

#include "sys/sys.h"

void goSecondWatchMode(void);
void suspendSecondWatchMode(void);
void resetSecondWatchMode(void);
void showSecondWatch(void);


#endif



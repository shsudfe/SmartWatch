#ifndef __GPIOEXTI_H
#define __GPIOEXTI_H

#include "sys/sys.h"


extern uint8_t key1_IT_Flag;

uint8_t getKeyITFlag(void);


#endif


